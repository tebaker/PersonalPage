Talon Baker
Assignment 4: Texturing and Coloring Geometric Objects
https://people.ucsc.edu/~taebaker/CMPS160/ASSG_04/driver.html